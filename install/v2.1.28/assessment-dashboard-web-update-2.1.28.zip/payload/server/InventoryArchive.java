package assessment;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.*;
import static assessment.AssessmentServer.map;

/** Portable inventory only: never serialize the database or operational/account tables. */
final class InventoryArchive {
    static final long MAX_BYTES=512L*1024*1024, MAX_RECORDS=1_000_000;
    static final List<String> COLLECTIONS=List.of("environments","hosts","runtimes","processes","servers","libraries","applications","datasources");
    private static Set<String> keys(String value){return Set.of(value.split(" "));}
    private static final Set<String> ENV=keys("id name");
    private static final Set<String> HOST=keys("id environmentId hostname fqdn osName osVersion kernelVersion distribution architecture ipAddresses logicalCpus cpuModel memoryTotalBytes memoryAvailableBytes memoryFreeBytes collectorVersion collectorJavaVersion collectorJavaVendor lastSeen lastAssessmentAt firstAssessmentAt registeredAt agentLifecycle status observedAt coverage disks");
    private static final Set<String> RECORD=keys("id hostId name version distribution type kind category path javaHome javaVersion javaVendor vendor architecture inUse usage state status observedAt discoveredAt applicationId applicationName applicationType applicationPath applicationPid applicationSource applicationDeployment applicationLinkEvidence serverId serverName serverType serverVersion runtimeId processId pid launchJar mainClass startClass module moduleName frameworkVersion framework applicationFramework springBootVersion springBootLibrary discoveryMethod scanScope evidence evidenceLevel domainName domainPath configurationSource configurationBinding configuredTargets configuredEnabled configuredMaxPoolSize configuredName configurationScope configurationResolution configurationContext configurationEvidence configurationKey configurationObservation activationUnresolved driverName driverVersion driverArtifact driverResolution driverVersionEvidence driverVersionSource driverResolutionReason driverResolutionCaveat driverConfidence driverClass driverClassEvidence driverFamily driverModule driverDeployment driverReference driverReplacedOnDisk databaseType databaseVersion databaseVersionEvidence databaseTypeEvidence databaseEndpointEvidence databaseHost databasePort databaseName databaseEndpoints datasourceKey datasourceObservation jndi jndiName jndiNames jndiEvidence jndiResolution resourceType linkedDatasourceId linkedContexts applicationReportedAtEpochMillis activeProfiles containerized contextIdentity descriptor sourcePath runtimeMetadataSource runtimeReplacedOnDisk runningVersions patches poolCapacity poolAvailable activeConnections capacity available connections deploymentPath deploymentName contextPath context linkName resolvedFrom launcherObservation excludedPathObservation tomcatApplicationOnlyDriver tomcatInstallationEvidence support associations driverResult driverCandidates embeddedServers");
    // Nested objects are purpose-specific. Unknown keys are not carried to a future consumer.
    private static final Set<String> CANDIDATE=keys("path name version versionSource source sourcePath order open loaded family onClasspath replacedOnDisk selected selectionReason precedence evidence origin driverClass driverName driverVersion driverArtifact driverVersionSource driverResolution driverResolutionReason driverResolutionCaveat");
    private static final Set<String> ASSOCIATION=union(RECORD,keys("serverIds applicationIds driverCandidates effectiveClasspathComplete classpathTruncated argumentsTruncated"));
    private static final Set<String> COVERAGE=keys("status warnings stats lastAssessmentAt");
    private static final Set<String> STATS=keys("durationMillis filesVisited bytesRead collectorCpuMillis peakHeapBytes collectorPeakRssBytes archivesInspected scanRoots processScanRoots maxFiles sweepFilesVisited processLinkedFilesVisited");
    private static final Set<String> DISK=keys("mount totalBytes availableBytes");
    private static final Set<String> SUPPORT=keys("status dataReferencia produto fornecedor referencia linha fimPrincipal fimEstendido vigente observacao fonte confidence");
    private static final Set<String> ENDPOINT=keys("host port database service sid name type evidence");
    private static final Pattern PRIVATE_KEY=Pattern.compile("(?is)-----BEGIN [^-]*PRIVATE KEY-----.*?(?:-----END [^-]*PRIVATE KEY-----|$)");
    private static final Pattern URL_LOGIN=Pattern.compile("(?i)([a-z][a-z0-9+.-]*://)[^/\\s@]+@");
    private static final Pattern ORACLE_LOGIN=Pattern.compile("(?i)(jdbc:oracle:[^:]+:)[^/@\\s]+/[^@\\s]+@");
    private static final Pattern AUTH_HEADER=Pattern.compile("(?i)\\b(Bearer|Basic)\\s+[A-Za-z0-9._~+/=-]+");
    private static final Pattern ASSIGNMENT=Pattern.compile("(?i)((?:username|user_name|userid|user_id|user|password|passwd|pwd|secret|token|credential|authorization|api[_-]?key|access[_-]?key)[\"']?\\s*[=:]\\s*)(?:\"[^\"]*\"|'[^']*'|[^\\s;,&)]+)");
    static final class Failure extends RuntimeException {Failure(String message){super(message);}}
    private static Set<String> union(Set<String> a,Set<String> b){Set<String> result=new HashSet<>(a);result.addAll(b);return Set.copyOf(result);}

    static String label(String value){
        String v=value==null?"":value.trim();
        if(v.length()>120||v.chars().anyMatch(c->Character.isISOControl(c)))throw new Failure("A identificação deve ter até 120 caracteres, sem quebras de linha.");
        return scrub(v);
    }
    /** Defense in depth for technical text. Raw JVM arguments, configuration and URLs are excluded by schema. */
    static String scrub(String value){
        String clean=PRIVATE_KEY.matcher(value).replaceAll("[REMOVIDO]");
        clean=URL_LOGIN.matcher(clean).replaceAll("$1[REMOVIDO]@");
        clean=ORACLE_LOGIN.matcher(clean).replaceAll("$1[REMOVIDO]@");
        clean=AUTH_HEADER.matcher(clean).replaceAll("$1 [REMOVIDO]");
        return ASSIGNMENT.matcher(clean).replaceAll("$1[REMOVIDO]");
    }
    static Map<String,Object> document(String collection,Map<String,Object> source){
        Set<String> allowed=collection.equals("environments")?ENV:collection.equals("hosts")?HOST:RECORD;
        return object(source,allowed,0);
    }
    private static Map<String,Object> object(Map<?,?> source,Set<String> allowed,int depth){
        if(depth>12)throw new Failure("Um registro excedeu a profundidade permitida para exportação.");
        Map<String,Object> result=new LinkedHashMap<>();
        for(var entry:source.entrySet()){
            String key=String.valueOf(entry.getKey());if(!allowed.contains(key))continue;
            Object v=entry.getValue();if(v==null){result.put(key,null);continue;}
            Set<String> nested=switch(key){case "coverage"->COVERAGE;case "stats"->STATS;case "disks"->DISK;case "support"->SUPPORT;case "linkedContexts"->keys("context contextPath applicationId applicationName serverId serverName sourcePath linkName");case "driverCandidates"->CANDIDATE;case "associations"->ASSOCIATION;case "databaseEndpoints"->ENDPOINT;case "embeddedServers","driverResult"->RECORD;default->Set.of();};
            Object clean=value(v,nested,depth+1);if(clean!=null)result.put(key,clean);
        }
        return result;
    }
    private static Object value(Object v,Set<String> nested,int depth){
        if(v instanceof String s)return scrub(s);
        if(v instanceof Boolean||v instanceof Number)return v;
        if(v instanceof Map<?,?> m)return nested.isEmpty()?null:object(m,nested,depth);
        if(v instanceof List<?> list){
            if(depth>12)throw new Failure("Um registro excedeu a profundidade permitida para exportação.");
            List<Object> result=new ArrayList<>();for(Object item:list){Object clean=value(item,nested,depth+1);if(clean!=null)result.add(clean);}return result;
        }
        return null;
    }
    static String format(String value){
        if(value==null||value.isEmpty())return "json";
        if(!Set.of("json","csv","xlsx","mapa").contains(value))throw new Failure("Escolha JSON, CSV, Excel ou Mapa de bancos para exportar.");
        return value;
    }
    static List<String> fields(){TreeSet<String> fields=new TreeSet<>(RECORD);fields.addAll(ENV);fields.addAll(HOST);return List.copyOf(fields);}
    static void write(OutputStream output,InventoryStore store,String label)throws Exception {write(output,store,label,"json");}
    static void write(OutputStream output,InventoryStore store,String label,String format)throws Exception {write(output,store,label,format,MAX_BYTES,MAX_RECORDS);}
    static void write(OutputStream output,InventoryStore store,String label,long byteLimit,long recordLimit)throws Exception {write(output,store,label,"json",byteLimit,recordLimit);}
    static void write(OutputStream output,InventoryStore store,String label,String requested,long byteLimit,long recordLimit)throws Exception {
        String title=label(label),format=format(requested),exportedAt=Instant.now().toString();
        try(ZipOutputStream zip=new ZipOutputStream(output,StandardCharsets.UTF_8)){
            Budget budget=new Budget(zip,byteLimit);long[] total={0};
            if(format.equals("xlsx")){
                zip.putNextEntry(new ZipEntry("inventario.xlsx"));
                store.readSnapshot(()->{writeWorkbook(zip,store,budget,title,exportedAt,recordLimit);return null;});
                zip.closeEntry();return;
            }
            if(format.equals("mapa")){
                zip.putNextEntry(new ZipEntry("mapa-bancos.csv"));
                store.readSnapshot(()->{writeMap(store,budget,title,exportedAt,recordLimit);return null;});
                zip.closeEntry();return;
            }
            zip.putNextEntry(new ZipEntry("inventario."+format));
            store.readSnapshot(()->{
                Map<String,Object> counts=new LinkedHashMap<>();
                for(String collection:COLLECTIONS){
                    boolean direct=collection.equals("hosts")||collection.equals("environments");
                    String sql=direct?"SELECT COUNT(*) AS n FROM "+collection:"SELECT COUNT(*) AS n FROM inventory WHERE kind=?";
                    long count=((Number)store.rows(sql,direct?new Object[0]:new Object[]{collection}).get(0).get("n")).longValue();
                    counts.put(collection,count);
                }
                Map<String,Object> metadata=map("format","java-assessment-inventory","formatVersion",2,"dashboardVersion",DashboardVersion.VERSION,"exportedAt",exportedAt,"label",title,"scope","all-current-inventory","counts",counts,"collections",COLLECTIONS,"containsCredentials",false);
                InventoryArchiveCsv csv=format.equals("csv")?new InventoryArchiveCsv(budget::text,store,fields()):null;
                if(csv==null)budget.text("{\"metadata\":"+Json.stringify(metadata)+",\"data\":{");else csv.start(metadata);
                boolean first=true;
                for(String collection:COLLECTIONS){
                    if(csv==null){if(!first)budget.text(",");budget.text(Json.stringify(collection)+":[");}first=false;
                    long[] count={0};
                    String sql=collection.equals("hosts")||collection.equals("environments")?"SELECT payload FROM "+collection+" ORDER BY id":"SELECT payload FROM inventory WHERE kind=? ORDER BY host_id,id";
                    Object[] args=collection.equals("hosts")||collection.equals("environments")?new Object[0]:new Object[]{collection};
                    store.forEachRow(sql,row->{
                        if(++total[0]>recordLimit)throw new Failure("O inventário excedeu o limite de registros para este pacote.");
                        @SuppressWarnings("unchecked") Map<String,Object> record=(Map<String,Object>)Json.parse(String.valueOf(row.get("payload")),32*1024*1024);
                        Lifecycle.decorate(collection,List.of(record),Instant.parse(exportedAt));
                        Map<String,Object> clean=document(collection,record);
                        if(csv==null){if(count[0]>0)budget.text(",");budget.text(Json.stringify(clean));}else csv.record(collection,clean);
                        count[0]++;
                    },args);
                    if(csv==null)budget.text("]");
                    if(count[0]!=((Number)counts.get(collection)).longValue())throw new Failure("O inventário mudou durante a exportação.");
                }
                if(csv==null)budget.text("}}\n");
                return null;
            });
            zip.closeEntry();
        }
    }
    static final Map<String,String> SHEETS=Map.of("environments","Ambientes","hosts","Máquinas","runtimes","Java","processes","Processos","servers","Servidores","libraries","Bibliotecas","applications","Aplicações","datasources","Datasources");
    private interface Row{void accept(Map<String,Object> clean)throws IOException;}
    private static void each(InventoryStore store,String collection,String exportedAt,Row action){
        boolean direct=collection.equals("hosts")||collection.equals("environments");
        String sql=direct?"SELECT payload FROM "+collection+" ORDER BY id":"SELECT payload FROM inventory WHERE kind=? ORDER BY host_id,id";
        store.forEachRow(sql,row->{
            @SuppressWarnings("unchecked") Map<String,Object> record=(Map<String,Object>)Json.parse(String.valueOf(row.get("payload")),32*1024*1024);
            Lifecycle.decorate(collection,List.of(record),Instant.parse(exportedAt));
            try{action.accept(document(collection,record));}catch(IOException e){throw new UncheckedIOException(e);}
        },direct?new Object[0]:new Object[]{collection});
    }
    /** One sheet per collection (columns present in that collection only) plus the database map; nested evidence summarized. */
    private static void writeWorkbook(OutputStream target,InventoryStore store,Budget budget,String title,String exportedAt,long recordLimit)throws IOException{
        InventoryArchiveXlsx book=new InventoryArchiveXlsx(target,budget::count);long[] total={0};
        Map<String,Long> counts=new LinkedHashMap<>();Map<String,Set<String>> keys=new LinkedHashMap<>();
        for(String collection:COLLECTIONS){
            Set<String> present=new HashSet<>();long[] n={0};
            each(store,collection,exportedAt,clean->{if(++total[0]>recordLimit)throw new Failure("O inventário excedeu o limite de registros para este pacote.");n[0]++;present.addAll(clean.keySet());});
            counts.put(collection,n[0]);keys.put(collection,present);
        }
        try(InventoryArchiveXlsx.Sheet summary=book.sheet("Resumo",List.of("campo","valor"))){
            summary.row(new ArrayList<>(List.of("formato","java-assessment-inventory (planilha)")));
            summary.row(new ArrayList<>(List.of("versão do dashboard",DashboardVersion.VERSION)));
            summary.row(new ArrayList<>(List.of("exportado em (UTC)",exportedAt)));
            summary.row(new ArrayList<>(List.of("identificação",title)));
            for(String collection:COLLECTIONS)summary.row(new ArrayList<>(List.of("registros: "+SHEETS.get(collection),counts.get(collection))));
            summary.row(new ArrayList<>(List.of("observação","Listas e evidências aparecem resumidas; a exportação JSON tem o detalhe completo. Banco configurado não comprova conexão ativa.")));
        }
        InventoryArchiveMap map=null;Map<String,String> machine=new HashMap<>(),environment=new HashMap<>(),envNames=new HashMap<>();
        for(String collection:COLLECTIONS){
            boolean context=!collection.equals("hosts")&&!collection.equals("environments");
            List<String> columns=InventoryArchiveXlsx.columns(keys.get(collection));
            List<String> header=new ArrayList<>();if(context){header.add("maquina");header.add("ambiente");}header.addAll(columns);
            try(InventoryArchiveXlsx.Sheet sheet=book.sheet(SHEETS.get(collection),header)){
                each(store,collection,exportedAt,clean->{
                    if(collection.equals("environments"))envNames.put(String.valueOf(clean.get("id")),InventoryArchiveMap.s(clean.get("name")));
                    if(collection.equals("hosts")){machine.put(String.valueOf(clean.get("id")),InventoryArchiveMap.s(clean.get("hostname")));environment.put(String.valueOf(clean.get("id")),envNames.getOrDefault(InventoryArchiveMap.s(clean.get("environmentId")),""));}
                    List<Object> values=new ArrayList<>();
                    if(context){String host=InventoryArchiveMap.s(clean.get("hostId"));values.add(machine.getOrDefault(host,""));values.add(environment.getOrDefault(host,""));}
                    for(String key:columns)values.add(InventoryArchiveXlsx.cell(key,clean.get(key)));
                    sheet.row(values);
                });
            }
        }
        try(InventoryArchiveXlsx.Sheet sheet=book.sheet("Mapa de bancos",InventoryArchiveMap.COLUMNS)){
            InventoryArchiveMap rows=new InventoryArchiveMap(values->{try{sheet.row(values);}catch(IOException e){throw new UncheckedIOException(e);}},title);
            for(String collection:List.of("environments","hosts","servers","applications","processes","runtimes"))each(store,collection,exportedAt,clean->rows.index(collection,clean));
            each(store,"datasources",exportedAt,rows::datasource);
        }
        book.finish();
    }
    /** Join tables first, then one row per datasource x endpoint x process; same allowlist and scrubbing as JSON/CSV. */
    private static void writeMap(InventoryStore store,Budget budget,String title,String exportedAt,long recordLimit){
        InventoryArchiveMap map=InventoryArchiveMap.csv(budget::text,title);long[] total={0};
        for(String collection:List.of("environments","hosts","servers","applications","processes","runtimes","datasources")){
            boolean direct=collection.equals("hosts")||collection.equals("environments");
            String sql=direct?"SELECT payload FROM "+collection+" ORDER BY id":"SELECT payload FROM inventory WHERE kind=? ORDER BY host_id,id";
            store.forEachRow(sql,row->{
                if(++total[0]>recordLimit)throw new Failure("O inventário excedeu o limite de registros para este pacote.");
                @SuppressWarnings("unchecked") Map<String,Object> record=(Map<String,Object>)Json.parse(String.valueOf(row.get("payload")),32*1024*1024);
                if(collection.equals("datasources")){Lifecycle.decorate(collection,List.of(record),Instant.parse(exportedAt));map.datasource(document(collection,record));}
                else map.index(collection,document(collection,record));
            },direct?new Object[0]:new Object[]{collection});
        }
    }
    private static final class Budget {
        private final OutputStream out;private final long max;private long bytes;
        Budget(OutputStream out,long max){this.out=out;this.max=max;}
        void count(String text){long size=text.getBytes(StandardCharsets.UTF_8).length;if(size>max-bytes)throw new Failure("O inventário excedeu o limite de 512 MiB descompactados para este pacote.");bytes+=size;}
        void text(String text){byte[] data=text.getBytes(StandardCharsets.UTF_8);if(data.length>max-bytes)throw new Failure("O inventário excedeu o limite de 512 MiB descompactados para este pacote.");bytes+=data.length;try{out.write(data);}catch(IOException e){throw new UncheckedIOException(e);}}
    }
}
