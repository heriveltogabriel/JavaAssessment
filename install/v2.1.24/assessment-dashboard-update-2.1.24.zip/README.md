# Dashboard 2.1.24

**Candidato exclusivo de laboratório.** Migração real, recuperação, Java 6/SysV e segundo canário ainda não validados para produção. Não entregar ao cliente nesta etapa.

Nesta pasta, execute `python3 publish-dashboard.py` no seu Terminal.

# Versão do dashboard

A versão é comum ao dashboard e ao agente e não usa sufixo beta. A entrega 2.0.0 reúne os retoques de interface e a revisão do reload. Cabeçalho, menu lateral, Sobre, `/health`, log inicial, exportação CSV, binário do agente, manifesto, metadata e nome do ZIP usam o mesmo número. A interface apresenta a versão completa como `Versão 2.0.0`.

## Preparar uma nova entrega

No Mac, na pasta do projeto:

```sh
python3 ops/build-dashboard-release.py
```

O comando incrementa automaticamente o patch, gera as versões do dashboard e do agente, recompila os dois, executa testes HTTP com o JAR real do agente e gera os pacotes em `output/dashboard-releases/<versão>/`. Ele imprime o caminho absoluto do publicador. Cada entrega tem sua própria pasta e seus próprios checksums; entregas anteriores não são sobrescritas. O agente continua compatível com Java6 (bytecode50).

Uma preparação que falhou reserva seu número; corrigir o problema e preparar outra entrega gera o próximo. Reenviar o mesmo pacote ou reiniciar o serviço não gera uma versão nova. Use este gerador para as próximas publicações; os geradores antigos representam entregas históricas.

Para uma mudança explícita de versão principal, use `python3 ops/build-dashboard-release.py --version 2.0.0`. O número solicitado deve ser uma versão estável maior que todas as versões já reservadas e que a versão atual do agente. Depois da entrega 2.0.0, o comando sem argumentos continuará com 2.0.1. Não repita a reserva de uma versão já preparada.

## Publicar

Execute no seu Terminal o comando `python3` com o caminho de `deployment/publish-dashboard.py` impresso pelo gerador. O publicador faz SCP, usa a chave `~/OneDrive/id_rsa` e publica somente em `167.126.4.37`. Ele preserva banco, configuração, CA e identidades; cria backup privado; inclui `VERSION` no rollback e exige que `/health` responda com a versão completa esperada. Não atualiza agentes nas VMs.

O pacote inclui o runtime Java sem compilador e o agente com a mesma versão da entrega. Aceita somente os hashes de bases conhecidas: entrega CSV confirmada, entrega de runtimes1.5.1 preparada e entregas anteriores do fluxo sequencial. A ausência de um recibo da última tentativa não é tratada como publicação bem-sucedida. Bases divergentes ou versão incorreta do pacote do agente são recusadas antes de parar o serviço.

Histórico de desinstalação com estados `SUCCEEDED`, `FAILED`, `CANCELLED` ou `EXPIRED` permite a atualização e é preservado. Pedidos `WAITING`, `UNINSTALLING` ou `UNCONFIRMED` bloqueiam a atualização; o diagnóstico apresenta apenas estados e quantidades. Estados desconhecidos também bloqueiam. A checagem usa uma transação de leitura e é repetida após a parada do serviço e após a publicação. O publicador não cancela pedidos nem apaga registros.

Após publicar, recarregue a página. A versão aparecerá no cabeçalho, no menu e em Sobre. Baixe novamente o ZIP do ambiente para obter o agente da mesma versão e atualize cada VM: extraia em uma pasta nova e execute `sudo ./install.sh --system-root`. A configuração e a identidade existentes são preservadas. As VMs continuam reportando a versão real antiga até receberem essa atualização; publicar o dashboard não atualiza o agente instalado.

Se o servidor não responder com metadados válidos, a interface mostra a versão como indisponível.

Tudo é preparado e validado localmente pelo Codex. A publicação remota é executada pelo usuário no Terminal.

A partir de 1.5.4, o login usa contas individuais (Administradores/Leitura). Veja `docs/USER_ACCESS.md` para primeiro acesso, permissões e recuperação protegida. Após ativar as contas, o rollback para autenticação por senha compartilhada é bloqueado.

A partir de 1.5.7, o menu ⋮ das máquinas permite mover, remover do ambiente e excluir o cadastro com proteção. Veja `docs/MACHINE_ACTIONS.md`. A preservação das contagens é verificada com o serviço parado; contagens após reiniciar são informativas porque administradores podem excluir registros durante a verificação.


# Contas individuais e administração

O dashboard usa nome, email único e senha individual. Há dois grupos fixos: **Administradores** e **Leitura**. Ambos consultam o inventário de todos os ambientes; os filtros de ambiente continuam disponíveis. Leitura pode abrir detalhes e exportar CSV. Administradores também gerenciam coleta, ambientes, agentes, códigos, usuários e acessos.

## Primeiro acesso depois da atualização

1. Abra o dashboard. A configuração inicial pede a senha administrativa que você já usava.
2. Informe seu nome, email e uma nova senha pessoal de 8 a 128 caracteres. A nova senha deve ser diferente da anterior.
3. Sua conta será criada no grupo Administradores. Os próximos acessos usam email e senha.

Essa ativação ocorre uma única vez e preserva o inventário. Reiniciar o serviço não recria o administrador. A senha compartilhada deixa de autenticar assim que a conta individual é ativada. A configuração inicial não pode ser assumida por um visitante sem a credencial administrativa atual.

Em instalações novas, o instalador pede nome/email do primeiro administrador e gera uma senha temporária protegida. A conta já existe antes de o servidor começar a atender. Use o email e a senha temporária fornecidos pelo instalador, e defina sua senha pessoal antes de acessar o inventário.

## Administrar usuários

Abra **Administração → Usuários → Adicionar usuário**. Informe nome, email e grupo. Leitura vem selecionado inicialmente. Confirme sua própria senha para autorizar a criação.

O dashboard mostra uma senha temporária aleatória uma única vez, válida por 24 horas. Copie-a e entregue-a à pessoa por um canal apropriado. Não há envio automático de email. A pessoa deve trocá-la no primeiro acesso, antes de consultar qualquer dado.

Em **Gerenciar**, você pode editar nome/email/grupo, desativar ou reativar a conta, ou gerar uma nova senha temporária. Email, grupo, habilitação e redefinição de senha encerram as sessões anteriores. O último administrador habilitado não pode ser desativado ou movido para Leitura. As contas são desativadas, sem exclusão do histórico.

**Grupos** explica as permissões dos dois grupos fixos. **Atividade** mostra os 200 eventos mais recentes, com a pessoa responsável e data/hora. O banco mantém até 10.000 eventos de acesso/administração; não registra senhas, hashes ou cookies. Administradores não conseguem visualizar a senha pessoal de outro usuário.

## Minha conta e sessões

A barra superior mostra a conta conectada. Abra o menu para consultar Minha conta, trocar sua senha ou sair. A troca de senha encerra outras sessões da mesma conta e mantém seu grupo.

As senhas aceitam frases, espaços e gerenciadores, sem regras de composição ou troca periódica. São armazenadas com Argon2id, salt individual e parâmetros versionados (19MiB, duas iterações, paralelismo1). O cálculo tem concorrência limitada a duas operações. O custo foi medido localmente; confirme o tempo de resposta após publicar no servidor real.

As sessões expiram após 30 minutos sem atividade ou 8 horas de duração máxima. A atualização automática do inventário usa `X-Assessment-Background: 1` e não prolonga a inatividade. O servidor confere conta, grupo, status e revisão de autorização a cada requisição. Há limitação progressiva de tentativas por email e origem, cookies HttpOnly/Secure/SameSite, CSRF e rotação de sessão. As credenciais dos agentes são independentes das contas humanas.

## Atualizar e recuperar pelo Terminal do Mac

Na pasta `deployment` da entrega 1.5.6, execute `python3 atualizar-e-recuperar-acesso.py`. O comando publica a versão com mínimo de 8 caracteres, confirma a versão e abre a recuperação interativa na máquina do dashboard. Usa a mesma chave SSH do publicador. Se a publicação já foi confirmada, pode repetir apenas a etapa de recuperação.

Quando a configuração inicial não foi concluída, informe seu nome e email para criar o primeiro administrador. Se já existem contas, informe o email de um administrador listado. A ferramenta cria backup privado do banco e da configuração, pausa o serviço, gera uma senha temporária e reinicia o serviço. O inventário e os agentes são preservados. A senha temporária aparece no seu Terminal e em um registro privado de root na VM; não é gravada em relatórios no Mac. Entre com ela em até 24h e escolha uma senha pessoal de 8 a 128 caracteres.

## Correção da recuperação na versão1.5.6

Se a recuperação parou com `Arquivo ou pasta precisa ser privado: /root`, use o comando `python3 recuperar-acesso.py` da pasta `output/access-recovery/1.5.6-r2`. A publicação1.5.6 já foi concluída; essa entrada executa apenas a recuperação. Ela mantém as permissões de `/root` e protege a nova pasta de backup com0700 e a credencial com0600. O estado systemd `failed` após a parada só é aceito com todos os processos encerrados, conforme confirmado pelo PID principal, PID de controle e cgroup vazio.

## Recuperar o último administrador na máquina do dashboard

Esta recuperação é operacional e exige acesso ao sistema da máquina. Não existe endpoint público para contorná-la. Use a ferramenta incluída no servidor, como a conta do serviço, para evitar criar arquivos SQLite pertencentes a root:

1. Pare `java-assessment-dashboard.service` e confirme que está parado. A ferramenta também obtém o bloqueio exclusivo do servidor e recusa execução concorrente.
2. Crie um arquivo temporário com a senha temporária escolhida (8–128 caracteres), proprietário `java-assessment-dashboard`, modo `0600` ou `0400`. Use uma pasta privada pertencente à mesma conta; não inclua a senha na linha de comando ou no histórico.
3. Execute com o mesmo Java17+ usado por `run-server.sh` (substitua `JAVA_DO_SERVICO` e `ARQUIVO_PRIVADO` pelos caminhos absolutos verificados):

```sh
sudo -u java-assessment-dashboard JAVA_DO_SERVICO -Xmx128m \
  -Dorg.sqlite.tmpdir=/opt/java-assessment-dashboard/data/native \
  -cp '/opt/java-assessment-dashboard/classes:/opt/java-assessment-dashboard/lib/*' \
  assessment.UserAdminTool \
  --root /opt/java-assessment-dashboard \
  --mode recover \
  --email EMAIL_DO_ADMINISTRADOR_EXISTENTE \
  --password-file ARQUIVO_PRIVADO
```

4. A saída confirma a conta e a validade da senha temporária, sem imprimir a senha. Remova somente o arquivo temporário criado para esta operação.
5. Inicie o serviço novamente. Entre com o email e a senha temporária e faça a troca obrigatória.

A ferramenta recupera um administrador já existente; não eleva uma conta de Leitura. O modo `provision` é usado pelo instalador apenas antes de criar o primeiro administrador. Diretórios/arquivos vinculados por symlink, credenciais com modos inseguros ou proprietário inesperado são recusados.

## Atualização e recuperação de versão

Use o publicador da entrega atual. O banco, as identidades dos agentes e os dados de inventário são preservados. Após ativar contas individuais, o marcador persistente `humanAuthActivated` impede que o atualizador restaure uma versão que aceite a antiga senha compartilhada. Se uma verificação falhar nessa situação, ele mantém o código com suporte às contas e o banco, registra o motivo e tenta restabelecer esse serviço. Não restaure manualmente um código anterior ao suporte de contas sobre um banco já migrado.

O fluxo local prepara os pacotes e as evidências; publicar na VM é uma etapa manual. A versão da entrega é comum ao dashboard e ao pacote do agente. Agentes já instalados continuam reportando sua versão real até serem atualizados.


# Ações por máquina

Administradores encontram o menu **⋮** nos cartões e na lista **Machines**.

- **Mover para outro ambiente** muda a associação da máquina e preserva o inventário e o histórico.
- **Remover do ambiente** deixa a máquina em **Unassigned**, preservando os dados. Depois de remover ou mover todas as máquinas, o ambiente pode ser excluído.
- **Excluir máquina do dashboard** remove o cadastro, inventário, tarefas e histórico de desinstalação da máquina selecionada. Exige digitar seu nome exato e só fica disponível depois de revogar o agente ou concluir sua desinstalação. Desinstalações pendentes, em execução ou sem confirmação bloqueiam a exclusão.

Revogar a credencial impede novas coletas, mas mantém a máquina vinculada ao ambiente. Essas ações não desinstalam nem executam comandos na VM. O perfil de leitura não pode realizá-las.

A exclusão é atômica e restrita ao administrador. O servidor conserva uma identificação mínima revogada, sem o token em texto, para impedir o uso da credencial antiga ou o recadastro da mesma instalação. Para cadastrar novamente a máquina, use uma nova instalação/identidade do agente.

## Publicação

A versão 1.5.7 inclui esse menu e a API de exclusão. Atualize o dashboard pelo `deployment/publish-dashboard.py` dessa versão. Não é necessário atualizar os agentes instalados para usar essas ações. A versão do pacote disponível para download acompanha a do dashboard.


# Atualização do agente pelo dashboard

A atualização usa HTTPS iniciado pelo agente, com sua identidade já registrada. Não exige chave SSH, porta de entrada na VM ou IP público na máquina do agente.

## Primeira instalação

Instale uma vez a versão habilitadora com `sudo ./install.sh --system-root`, a partir do ZIP do ambiente extraído em uma pasta nova. O instalador preserva a identidade existente e instala o executor protegido de atualização. Agentes antigos, instalações manuais e cron aparecem como incompatíveis até essa etapa.

## Passagem para 2.0.2

A 2.0.2 corrige o executor, seus scripts e a confirmação de heartbeat. Execute uma vez o instalador completo com `--system-root` em cada máquina, preservando a identidade existente. O dashboard lê a geração efetivamente instalada: `update-v1` não atende ao mínimo assinado `minUpdater=2` desta entrega e recebe a orientação para usar o instalador. `update-v2` aceita manifestos de gerações 1 e 2, mas continuam obrigatórias versão superior e igualdade dos arquivos de suporte. O protocolo de solicitação permanece `UPDATE_AGENT_V1`.

Falta de rede ou timeout do heartbeat deixam o pedido sem confirmação, com journal e backup preservados para nova tentativa. Falha do probe de código continua provocando rollback. Não cancele/apague arquivos de uma atualização que já começou para forçar outra instalação.

## Uso

Como Administrador, abra o ambiente e a aba **Machines**. Clique em **Atualizar agentes do ambiente**, ao lado de **Enrollment codes**, para ver todas as máquinas desse ambiente. A busca e a paginação da tabela não reduzem essa prévia. Confira o nome do ambiente, a versão instalada e a versão disponível; marque máquinas específicas ou **Selecionar elegíveis** e confirme. Em **All environments**, o botão **Atualizar agentes** permite selecionar entre todos os ambientes. Máquinas sem ambiente têm sua própria seleção.

O menu **⋮ → Atualizar agente** de uma linha atua somente naquela máquina. A entrada global **Actions → Atualizar agentes** continua disponível e segue o contexto atual. O dashboard explica por que uma máquina não pode ser atualizada. Acompanhe os estados após confirmar e use **Ver em Work requests** para abrir o histórico do lote e os detalhes de cada máquina. O resumo na tela do ambiente permite retornar às atualizações em andamento mesmo após fechar a janela. O perfil Leitura pode acompanhar pedidos, mas não pode iniciar nem cancelar atualizações. Consulte [Acompanhamento em Work requests](WORK_REQUESTS.md).

O agente recebe a solicitação na próxima conexão; a máquina offline aguarda até expirar o pedido. Em um lote, somente uma máquina é atualizada por vez. Uma falha ou restauração cancela as solicitações que ainda aguardavam naquele lote. Um resultado sem confirmação interrompe o avanço até haver uma confirmação válida.

## Proteções e limites

O formato inicial atualiza `collector.jar`, que contém o código Java do agente. Scripts de instalação, bibliotecas TLS, chave pública, configuração, identidade, ambiente e inventário são preservados. O agente exige que todos os arquivos estáveis instalados coincidam com os hashes do manifesto assinado. Uma versão que dependa de mudanças nesses arquivos exige o instalador completo e não é aplicada pelo atualizador remoto.

O pacote precisa ter assinatura RSA3072/SHA256 válida, versão superior à instalada, tamanho e hash corretos e compatibilidade com o executor instalado. O dashboard não pode enviar scripts livres, uma URL arbitrária ou um caminho para executar como root. O executor troca o JAR usando arquivo temporário e rename no mesmo sistema de arquivos, mantém backup privado e verifica o novo código. Falha local restaura a versão anterior. Falta de rede não é interpretada como sucesso.

Enquanto há atualização ativa, coleta nova, mudança de ambiente, exclusão e desinstalação são bloqueadas para aquela máquina. O publicador também bloqueia a atualização do próprio dashboard enquanto houver pedidos de atualização de agente pendentes ou sem confirmação. Se um pedido começar após o dashboard voltar ao ar e a verificação da publicação falhar, o publicador preserva a versão que autorizou esse pedido, em vez de remover seu catálogo num rollback.

## Chave de assinatura

A chave privada fica somente no Mac em `output/agent-update-signing/private-key.pem`, em diretório com permissão `0700` e arquivo `0600`. Ela não é enviada ao dashboard nem incluída nos ZIPs. Preserve um backup protegido dessa chave para assinar versões futuras. O instalador fixa a chave pública inicial; este protocolo não troca a chave silenciosamente. Perder a chave privada exigirá um procedimento explícito de migração de confiança e reinstalação.

O gerador `python3 ops/build-dashboard-release.py` recompila dashboard e agente com a mesma versão, cria o pacote e seu manifesto assinado e mantém as entregas anteriores imutáveis. Publicar o dashboard disponibiliza uma versão nova; atualizar agentes continua exigindo a ação explícita do administrador.


# Acompanhamento em Work requests

Abra **Work requests** no menu lateral para consultar coletas e atualizações de agentes em uma página própria. O menu abre todos os ambientes. Um atalho de acompanhamento dentro de um ambiente ou máquina abre essa mesma página com o contexto e o pedido selecionados. Uma atualização de várias máquinas aparece como um único pedido; seus detalhes mostram cada máquina, a versão anterior, a versão solicitada e o resultado.

A busca por texto permanece visível. O botão **Filtros** abre ou recolhe ambiente, tipo, estado e período. Recolher o painel preserva os critérios aplicados e os valores em edição; o resumo e a opção **Limpar** continuam visíveis. A escolha de expansão permanece durante a navegação da sessão. Work requests aparece separado dos links de inventário e de Administração no menu lateral.

Após confirmar uma atualização, a janela mostra o acompanhamento e oferece **Ver em Work requests**. Fechar a janela não cancela o pedido. O resumo na tela do ambiente permite voltar aos lotes ativos; os detalhes podem ser reabertos depois de recarregar a página.

As informações são atualizadas periodicamente enquanto a página está visível. As contagens representam estados informados pelos agentes: aguardando, baixando, instalando, verificando, atualizado, falhou, versão anterior restaurada ou aguardando confirmação. O dashboard só mostra sucesso depois de receber as confirmações exigidas pelo protocolo. A ausência de confirmação não é interpretada como conclusão.

Nos detalhes, cada máquina mostra uma linha do tempo com os eventos e horários disponíveis. Pedidos anteriores a esta versão podem ter histórico parcial: são exibidos os registros existentes, sem inventar horários intermediários. Falha ou restauração de uma máquina interrompe o restante do lote; os pedidos cancelados por esse motivo indicam a causa.

**Coleta parcial** significa que o resultado chegou com limitações de cobertura. **Atualização parcial** significa que o lote terminou com resultados diferentes entre as máquinas; a tela apresenta as contagens reais. **Ver motivo** abre as observações do pedido. Novas coletas preservam seus próprios avisos, mesmo após uma coleta posterior. Para pedidos antigos sem avisos salvos, o dashboard informa a indisponibilidade; a cobertura atual só serve de evidência daquele pedido quando o horário corresponde à mesma coleta. A tela identifica essa origem.

O perfil **Leitura** pode acompanhar os pedidos. Somente um **Administrador** pode cancelar uma máquina que ainda esteja aguardando o agente. Quando a instalação já começou, a operação segue o fluxo protegido do agente.

O histórico das atualizações concluídas é preservado quando uma máquina é removida do inventário. Links salvos para esses pedidos continuam abrindo com seu escopo histórico, mesmo sem a máquina no inventário atual. Novos pedidos guardam o nome da máquina, o ambiente e o solicitante no momento da solicitação. Os eventos apresentados são diagnósticos do protocolo de atualização; não são uma cópia integral dos logs do sistema operacional.


# Datasources JDBC de Tomcat e JBoss/WildFly

O coletor identifica declarações de datasource nas configurações dos servidores associados a processos Java observados. A descoberta acontece antes da inspeção de JARs e utiliza o diretório do processo, mesmo fora dos caminhos de varredura geral. Exclusions e montagens de rede continuam prevalecendo.

## O que foi encontrado na investigação

O código anterior criava registros de datasource a partir da configuração base de Spring Boot e do snapshot JMX de WebLogic. Tomcat e JBoss/WildFly eram identificados por processo e metadados de produto/driver, mas seus XMLs de datasource não eram lidos. As fontes arquivadas nas versões 1.5.3, 1.5.4, 1.5.6, 1.5.7, 1.5.8, 1.5.9, 1.5.10 e 1.5.11 confirmam essa lacuna: os dois pontos de inclusão de datasources são Spring e WebLogic; não há descoberta de `server.xml` ou `standalone.xml`.

A evidência local `docs/application-discovery-limited-validation.json`, de 9 de outubro de 2026, também registra zero datasources em `instance-ol8` e `instance-web`, com cobertura limitada por permissões. O histórico `docs/superpowers/plans/2026-10-09-jdbc-summary.md` registra uma investigação anterior sobre a diferença entre contagem de drivers e datasources e a implementação posterior de descoberta Spring.

Esses arquivos demonstram uma lacuna de descoberta que esta mudança corrige. Não demonstram o motivo exato da mudança de contagem observada agora no ambiente real de Desenvolvimento: o estado atual dos processos e configurações dessas VMs não foi inspecionado nesta validação local.

## Suporte

- **WebLogic:** domínio obtido de `weblogic.RootDirectory` ou do diretório de trabalho do processo observado. Lê `config/config.xml` e somente os módulos JDBC ali referenciados em `config/jdbc`. Retém nome, JNDI, classe de driver, família de banco, capacidade máxima configurada e targets declarados. Arquivos órfãos, caminhos que escapam do diretório, credenciais e URLs completas não entram no inventário. Associações indicam processos observados usando o domínio; os targets configurados são preservados separadamente e não comprovam implantação ou saúde do pool. Não cobre módulos dentro de EAR, deployment plans, sobreposições nem configurações mantidas somente em runtime. A integração opcional de snapshots JMX anteriores permanece independente, com seu horário original.

- **Tomcat:** `CATALINA_BASE/conf/server.xml` (`GlobalNamingResources/Resource` e `Context/Resource`), `conf/context.xml`, descritores `conf/<Engine>/<Host>/*.xml` e `context.xml.default`, e `webapps/<aplicação>/META-INF/context.xml` de aplicações expandidas. Os recursos precisam declarar `javax.sql.DataSource` ou `javax.sql.XADataSource`. `ResourceLink` referencia o recurso global, sem aumentar sua contagem.
- **JBoss/WildFly standalone:** `standalone/configuration/standalone.xml`, ou o diretório indicado por `jboss.server.base.dir`/`jboss.server.config.dir` e o arquivo selecionado por `-c`, `--server-config` ou `--read-only-server-config`, com formas `=arquivo` quando aplicáveis. Suporta o namespace `urn:jboss:domain:datasources:*`, `datasource`, `xa-datasource`, referências às classes declaradas em `drivers` e limites configurados de pool. Não lê configurações alternativas quando o processo selecionou outra.
- O mesmo arquivo e recurso/contexto não são contados outra vez por processos que o compartilham; cada associação é preservada separadamente. Recursos com o mesmo nome em diferentes contextos/origens continuam distintos.

## Significado dos registros

`evidenceLevel=configuration` e `state=CONFIGURED` significam **configuração encontrada**. Um processo Java observado e um XML selecionado não comprovam ativação efetiva, carregamento do driver, conexão com banco ou saúde do pool. O arquivo pode ter mudado após a inicialização.

O coletor conserva nome do recurso, origem, contexto, horário, associação ao processo/servidor/aplicação, classe do driver, tipo de banco deduzido sem reter a URL e máximo de pool configurado quando disponível. Não inventa versão do driver ou métricas de execução. `configuredMaxPoolSize` é diferente de capacidade/uso medidos em runtime.

`enabled=false` em JBoss produz `state=DISABLED` e `configuredEnabled=false`. Expressões não resolvidas não são executadas; ativação variável aparece com `activationUnresolved=true`. Declarações desativadas continuam sendo configurações inventariadas, sem alegar que estão ativas.

## Segurança e limites

O parser SAX bloqueia DOCTYPE, entidades externas, DTD externo e XInclude, usa processamento seguro e nunca faz requisições de rede ou abre conexão JDBC. Não executa classes descobertas e não altera arquivos ou permissões das aplicações. Usuário, senha, URL JDBC completa, propriedades XA e XML bruto não entram no resultado, cache ou diagnóstico. Erros do parser têm mensagem genérica, pois exceções poderiam conter valores do arquivo.

Limites: 256 KiB por XML, 128 arquivos por coleta, 512 entradas examinadas por diretório, 12.000 elementos e 64 níveis por XML, 1.024 caracteres por contexto, 512 registros de datasource no inventário e no cache agregado e 16 associações por recurso. Ao atingir o limite de linhas, novos arquivos deixam de ser lidos; recursos já em cache ainda podem receber associações de outros processos. Compartilha os limites globais de arquivos, tempo e 8 MiB de leitura de metadados. Arquivos ausentes obrigatórios, inválidos, inseguros, inacessíveis ou acima dos limites geram aviso de cobertura; o inventário antigo não é reapresentado como atual.

A descoberta é vinculada a processos identificados. Não cobre servidor parado, perfil domain ou JBoss legado, configuração somente em management runtime, Agroal, descritores dentro de WAR não expandido, caminhos Tomcat customizados de `appBase`/`xmlBase` ou configurações externas herdadas que não estejam nos locais descritos. Não resolve variáveis, sobreposições, perfis nem seleção de recursos efetivos por aplicação.

## Validação e uso

`assessment.ServerDataSourcesTest` cria configurações e `/proc` sintéticos sem iniciar servidores de aplicação ou bancos. Cobre Tomcat e JBoss, namespaces, XA/desativação, configuração selecionada, associação e deduplicação, XML inválido/XXE, sigilo por canários, limites, exclusões e regressões. O conjunto passou 77 verificações com heap de 64 MiB, incluindo arquivos repetidos e XMLs com contextos artificialmente aninhados, além de compilação com bytecode Java 6 e `--release 8`. A opção `--export caminho.json` exporta os registros reais gerados por essas fixtures para testes autenticados de ingestão e overview. As regressões existentes Spring, WebLogic, inventário de JVM, launcher, arquivos e coleta também devem passar.

Para repovoar o dashboard de uma máquina que usa esses formatos, atualize o agente para a versão que inclui `ServerDataSources` e solicite uma nova coleta. Publicar apenas o dashboard não acrescenta dados que o agente antigo não envia. Depois confira Work requests, avisos de cobertura e o caminho de origem de cada datasource. Uma nova coleta realmente vazia deve continuar vazia, em vez de preservar dados antigos como se fossem observações novas.

## Referências primárias

- [WebLogic 10.3.6 JDBC resources](https://docs.oracle.com/middleware/11119/wls/JDBCA/config.htm): módulos referenciados em `config.xml` e descritores em `config/jdbc`.

- [Tomcat JNDI Resources](https://tomcat.apache.org/tomcat-9.0-doc/jndi-resources-howto.html): configuração dos recursos em Context e GlobalNamingResources.
- [Tomcat Context](https://tomcat.apache.org/tomcat-9.0-doc/config/context.html): descritores por aplicação, Resource e ResourceLink.
- [WildFly Admin Guide](https://docs.wildfly.org/26/Admin_Guide.html): argumentos de seleção de configuração e diretório `jboss.server.config.dir`.


# Cenário de homologação: atualização remota sem SSH

Objetivo: habilitar o mecanismo uma vez numa VM de teste e realizar a próxima atualização pelo dashboard, verificando versão, identidade e inventário.

## Preparação

Use uma VM Linux de homologação com saída HTTPS para o dashboard, serviço do agente instalado como root e comando `flock` disponível. Use um ambiente dedicado chamado **Teste de atualização**. Mantenha uma sessão no console da VM durante a primeira validação, para observar o serviço e os logs locais.

As versões de habilitação e destino, os comandos absolutos de publicação e os resultados automáticos serão registrados na entrega final em `output/agent-update/TESTE.md`. Os pacotes não são publicados nem instalados nas VMs pelos testes locais.

## Execução com a VM

1. Publique a versão habilitadora no dashboard pelo publicador do Mac.
2. No ambiente de teste, baixe o ZIP habilitador, transfira-o para a VM e extraia em uma pasta nova. Execute `sudo ./install.sh --system-root` uma vez. Se a identidade já estiver revogada, use uma nova instalação/identidade autorizada; atualizar não reativa credenciais revogadas.
3. Aguarde a máquina conectar. Anote seu ID, ambiente, versão do agente e quantidade de instalações Java. Confirme que a atualização remota é reconhecida como disponível para versões futuras.
4. Publique no dashboard a versão de destino preparada em seguida.
5. Na máquina de teste, escolha **⋮ → Atualizar agente**, confira as versões e confirme.
6. Acompanhe o pedido até concluir. Confira que o agente informa a versão nova, conserva o mesmo ID e ambiente e ainda tem o inventário anterior. Solicite uma coleta para confirmar operação normal.

## Resultados esperados

- Sucesso: mesmo registro, versão nova confirmada pelo agente e coleta posterior funcionando.
- Máquina offline: pedido aguardando; volta a conectar dentro da validade e processa o pedido. Expirado não deve executar.
- Perfil Leitura: não consegue iniciar/cancelar pela interface nem pela API.
- Agente antigo: exige instalação habilitadora, sem tentar executar um mecanismo inexistente.
- Pacote adulterado: recusado antes da troca do JAR.
- Código novo defeituoso: versão anterior restaurada, pedido marcado como restaurado e lote interrompido.

Os dois últimos casos usam apenas o laboratório automatizado com chaves temporárias e arquivos descartáveis. Não adulterar pacotes nem instalar uma versão defeituosa numa máquina de aplicação.

## Evidência

Os testes locais distinguem validação real de assinatura/HTTP/SQLite/JAR de simulação de `systemd`/SysV. O ensaio na VM completa a verificação do gerenciador de serviço real. Não considerar mera ausência de heartbeat como sucesso ou desinstalação.


# Atualização completa do agente

O fluxo V3 substitui código, scripts, bibliotecas e manager como uma geração assinada. A configuração e a identidade ficam fora do pacote. O dashboard mantém uma operação por máquina, incluindo a transição de agentes antigos e a coleta posterior.

Esta implementação ainda exige os gates de Linux e canários registrados em [validação](validation/full-agent-update.md). O candidato 2.0.9 foi preparado exclusivamente para laboratório; sua preparação não confirma migração em Linux nem compatibilidade de produção.

## Caminhos de atualização

| Instalação | Caminho |
| --- | --- |
| Anterior a 1.5.12 | Instalador completo; nenhuma compatibilidade é inferida |
| A partir de 1.5.12, suporte e binários conhecidos, atualizador V1/V2 | Bridge assinado específico → limpeza/ACK original → recuperação independente → pacote final V3 |
| Atualizador V3 instalado | Pacote completo diretamente |
| Sem serviço root, suporte customizado ou perfil desconhecido | Reparação explícita pelo instalador completo |

A prévia identifica a migração como **verificação local pendente**. O número da versão identifica perfis candidatos; o atualizador antigo confere os arquivos e o probe confere o binário real antes da troca. Hashes e assinatura continuam obrigatórios.

O operador solicita a migração pelo próprio dashboard em **Máquinas → Ações → Atualizar agente**, mantém a opção de assessment se desejada e acompanha **Work requests**. O mecanismo já instalado baixa e aplica as etapas assinadas; não é necessário SCP, reinstalação manual ou chave SSH para essa atualização do agente. O publicador do dashboard e os diagnósticos de laboratório são operações separadas. Reiniciar a VM é um teste opcional de retomada, não uma etapa automática da migração.

O bridge tem número interno B, maior que as origens e menor que o destino T. O número exibido como alvo continua T. O sucesso de B não conclui o pedido nem permite uma coleta. B/T são reservados uma única vez; um bridge não é uma release de dashboard.

## Artefatos imutáveis

- `dist/agent-bundles/T/{manifest.json,manifest.sig,bundle.zip}`.
- `dist/agent-bridges/B/<hash-do-manifesto>/{manifest.json,manifest.sig,collector.jar}`.
- `dist/agent-update-routes/T/{routes.json,routes.sig}`.
- `dist/agent-update-public.der`: a chave já confiada pelos agentes.

Os formatos usam RSA-3072/SHA-256. O bridge conserva as oito chaves do manifesto V1 e seu ACK original. O catálogo fixa origem, hash do coletor, perfil de suporte, bridge e hash do manifesto final. Cada operação persiste seu catálogo e artefatos; uma release posterior não muda o seu destino.

O manifesto completo tem exatamente `schema`, `type`, `format`, `version`, `minUpdater`, `minJava`, `platform`, `bytes`, `sha256` e `files`. Nesta geração: schema 1, type `ASSESSMENT_AGENT_BUNDLE_V1`, format `agent-bundle-v1`, minUpdater 3, minJava 6 e platform `linux`.

Cada arquivo tem tamanho, SHA-256, modo 600/700 e papel: code, manager, bootstrap ou default. Há limites de 64 MiB transferidos, 128 MiB expandidos e 256 arquivos. O verificador compartilhado recusa links, arquivos especiais, duplicatas, caminhos inseguros e divergências de CRC/tamanho/hash. O JAR V1 continua limitado a 32 MiB e bytecode Java 6.

## Estado preservado e recuperação

A extração inicial pode ocorrer em qualquer pasta privada. A instalação root usa `/opt/java-assessment-collector`; o atualizador usa `/opt/java-assessment-update`.

| Área | Tratamento |
| --- | --- |
| Configuração, identidade, installation-id, CA indicada e Java selecionado | Preservados, com hashes conferidos antes da ativação |
| Spool, resultados pendentes e logs | Permanecem na área de estado |
| Releases e managers | Diretórios versionados e ponteiro JSON validado |
| Bootstrap/âncora e bibliotecas próprias | Recuperação independente, preservada entre atualizações |
| Código anterior funcional | Retido para restauração |
| Arquivos desconhecidos ou alterados | Preservados; impedem remoção automática do diretório |

O coletor que prepara a migração encerra seu ciclo. Um serviço separado espera sua saída, adquire o lock global, prepara recuperação e ativa a nova geração. O processo antigo não pode confirmar o manager que acabou de substituir: uma nova execução do manager promovido precisa conferir serviços e heartbeat final.

Falha local de candidato, manager ou serviço restaura a origem. Falha de rede depois da verificação local mantém a geração íntegra e o pedido aguardando confirmação. O journal permite retomada e repetição de ACK sem reinstalar. Autorização vencida não dá permissão ilimitada para baixar ou ativar código.

A limpeza usa inventários de propriedade e referências, preservando ativo, anterior funcional e recuperação. Não percorre diretórios de aplicações nem remove a JVM. A desinstalação V3 também usa plano durável e recusa conteúdo desconhecido.

O JAR no caminho raiz pode permanecer como artefato de recuperação. Depois da migração, consulte a release ativa pelo diagnóstico abaixo, em vez de inferir a versão apenas desse JAR legado.

Para diagnóstico após a instalação V3:

```sh
sudo /bin/sh /opt/java-assessment-collector/agent-tool.sh version
```

## API e confirmação

Endpoints autenticados: `/api/agent/update-v3/action`, `claim`, `manifest`, `signature`, `package` e `report`. O transporte fica preso à origem configurada, sem redirecionar credenciais. Não há endpoint de execução de comandos arbitrários.

A action contém `operationId`, `targetVersion`, `expiresMillis` e `signedPlanHash`. O claim próprio do bundle é separado do claim do bridge. Downloads e reports exigem esse claim; a resposta inclui hashes do bundle e manager. O agente compara a rota recebida com a rota persistida.

O report informa status, versão, hashes e diagnóstico. O sucesso exige versão T, capacidade `update-v3`, hashes de bundle/manager e heartbeat autenticado posterior ao claim V3. Report final repetido retorna o mesmo ACK; report conflitante é recusado. As etapas não retrocedem depois de confirmação pendente.

Diagnósticos como `MIGRATION_PROFILE_REQUIRED`, `IDENTITY_CHANGED`, `INVALID_BUNDLE`, `INSUFFICIENT_DISK`, `MANAGER_PROBE_FAILED` e `RECOVERY_REQUIRED` indicam a intervenção necessária sem divulgar tokens ou configuração.

## Assessment posterior

A opção **Executar assessment após atualizar** vem marcada na interface. Clientes antigos da API que omitem o campo conservam o comportamento anterior: false. O booleano participa da identidade do pedido; o mesmo requestKey com outra escolha é recusado.

A intenção é criada uma vez e habilitada somente após confirmar T. Ela aproveita um job QUEUED ainda não iniciado ou cria um job `post-update`, usando a configuração efetiva no lease. Funciona com agendamento desligado, sem consumir a janela do agendamento normal.

Há uma coleta vinculada por ambiente, duas globais e dez segundos entre inícios por ambiente. A intenção que não iniciar em 24 horas expira. Revogação/remoção cancela a intenção; uma atualização mais recente pode substituí-la. Repetições, reinícios e ACK perdido não criam outro job.

Work requests mostra separadamente a atualização e a coleta, com links nos dois sentidos. Falha ou resultado parcial da coleta mantém o sucesso da atualização. O vínculo e seu resumo permanecem quando os detalhes antigos do job forem removidos.

## Build e evolução

`ops/full_agent_release.py` prepara assets a partir do pacote genérico e de origens com checksums independentes. O bundle é gerado antes de ser embutido como `full-update/{manifest.json,manifest.sig,bundle.zip}` no instalador, evitando autorreferência. O instalador usa esses assets em uma inicialização local administrativa, sem criar pedidos falsos na API. Instalações V3 existentes usam o fluxo completo pelo painel; uma reinstalação administrativa que poderia desmontar esse layout é recusada antes de parar serviços.

`reserve_update_pair()` reserva B/T sob o mesmo lock. O builder operacional inclui catálogo, bridges e bundle no runtime. A publicação preserva catálogos anteriores e recusa operações de atualização ocupadas, inclusive pais sem filho V1 ativo.

Uma futura mudança de schema/bootstrap exige nova regra explícita de compatibilidade. Não basta aumentar o número da versão. Bibliotecas do bootstrap anterior permanecem independentes das bibliotecas novas. O build herda a âncora e suas bibliotecas do primeiro instalador V3 assinado entre as origens verificadas; não a substitui pela âncora de cada release nova.

## Prazo de início por máquina

Na entrega 2.1.6, o primeiro pedido ainda não iniciado de cada lote recebe um prazo persistido de cinco minutos. A máquina seguinte ganha seu próprio prazo quando chega sua vez, limitado também pela validade global do pedido. A manutenção periódica (30 segundos) funciona sem heartbeat e sem navegador aberto.

O estado EXPIRED com diagnóstico AGENT_START_TIMEOUT libera a próxima máquina e cancela um bridge ainda não iniciado. Claims tardios são recusados nos protocolos legado e V3. Para tentar novamente após a máquina voltar, crie outro pedido pelo painel. O prazo não cancela uma instalação iniciada: UNCONFIRMED, recuperação e interrupção por falha real continuam com as regras existentes.


# Atualização de uma instalação existente 2.0.53

Use o ZIP **assessment-dashboard-update-VERSAO.zip** no servidor do cliente. O ZIP **installer** é para uma instalação nova e recusa um dashboard já instalado.

1. Confira o SHA-256, extraia o ZIP de atualização numa pasta nova e entre nela.
2. Execute `sudo /bin/sh atualizar-dashboard.sh`.
3. Confirme a versão no dashboard. Em **Revisar agentes**, selecione primeiro uma máquina e solicite a versão final. Depois de confirmar, atualize as demais. Execute uma coleta após a atualização.

O atualizador local usa a URL configurada para validar TLS e o SAN, conectando em loopback. Não depende de DNS externo, proxy ou acesso à Internet. Verifica os pacotes, a origem instalada e a chave pública dos agentes; faz backup privado do banco/configuração e troca o código com o serviço parado. Não reinstala, não recria usuários, não troca CA e não altera a URL. Recusa pedidos de atualização/desinstalação ainda ativos. O caminho do backup e o relatório de confirmação aparecem na saída; consulte o recibo antes de tentar novamente após erro.

**Agentes V3 2.0.53:** um pedido direto para a versão final, sem instalar 2.0.55 primeiro. O manager antigo recebe e verifica o pacote completo; o manager novo instala a correção de partida antes de confirmar. O número reservado à ponte de migração não é um passo manual; instalações que já usam V3 não usam a ponte.

A atualização do dashboard não atualiza agentes automaticamente. Elegibilidade depende dos arquivos assinados e do estado da instalação, não só do número. A extensão de partida suporta o serviço original; customizações desconhecidas são recusadas.

Antes do primeiro canário, se necessário, confira na máquina:

```sh
sudo systemctl is-active java-assessment-recovery.service
sudo systemctl show java-assessment-recovery.service -p MainPID -p ActiveState -p SubState
```

Em SysV, use `sudo service java-assessment-recovery status`. Não remova marcadores ou arquivos manualmente. Se o recuperador antigo já estiver parado, ele não consegue baixar a própria correção: confirme o diagnóstico e retome-o antes do pedido. Se está ativo, a correção é recebida pelo fluxo normal. Não é necessário reiniciar a máquina para atualizar.

Validações e limites em [recuperador/instalador](../validation/recovery-installer-2026-10-16.md). Os testes de serviço foram feitos no laboratório; não presumem as regras de rede, certificados ou personalizações do cliente.


**Atenção: atualize também os agentes para 2.1.24.** Publicar o dashboard não atualiza as máquinas automaticamente. Migrações conhecidas a partir de 1.5.12 exigem os perfis assinados; acompanhe atualização e assessment separadamente em Work requests.
